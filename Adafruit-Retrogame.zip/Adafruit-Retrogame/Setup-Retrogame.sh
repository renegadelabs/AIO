cp /home/pi/Adafruit-Retrogame/retrogame /usr/local/bin
sudo chmod 777 /usr/local/bin/retrogame
cp /home/pi/Adafruit-Retrogame/retrogame.cfg /boot
cp /home/pi/Adafruit-Retrogame/10-retrogame.rules /etc/udev/rules.d
cp /home/pi/Adafruit-Retrogame/retroarch.cfg /opt/retropie/configs/all
cp /home/pi/Adafruit-Retrogame/es_input.cfg /opt/retropie/configs/all/emulationstation

# Insert retrogame into rc.local before 'exit 0'
sed -i "s/^exit 0/\/usr\/local\/bin\/retrogame \&\\nexit 0/g" /etc/rc.local >/dev/null

# sudo bash /home/pi/Adafruit-Retrogame/Setup-Retrogame.sh
# Remove retrogame setup
sed -i '/Setup-Retrogame.sh/d' /etc/rc.local

reboot